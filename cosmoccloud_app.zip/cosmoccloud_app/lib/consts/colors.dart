import 'package:flutter/material.dart';

const Color primaryColor = Color.fromARGB(255, 0, 0, 0);
const Color secondaryColor = Color(0xFF0A73FF);
const Color backgroundColor = Color(0xFFF5F5F5);
