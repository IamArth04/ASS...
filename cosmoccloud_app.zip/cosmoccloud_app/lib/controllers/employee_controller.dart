// import 'package:flutter/material.dart';
// import 'package:cosmoccloud_app/services/api_service.dart';
// import 'package:cosmoccloud_app/models/employee.dart';

// class EmployeeController with ChangeNotifier {
//   List<Employee> _employees = [];
//   late ApiService _apiService;

//   EmployeeController() {
//     _apiService = ApiService();
//     fetchEmployees();
//   }

//   List<Employee> get employees => _employees;

//   Future<void> fetchEmployees() async {
//     _employees = await _apiService.fetchEmployees();
//     notifyListeners();
//   }

//   Future<void> addEmployee(Employee employee) async {
//     await _apiService.addEmployee(employee);
//     fetchEmployees();
//   }

//   Future<void> deleteEmployee(String id) async {
//     await _apiService.deleteEmployee(id);
//     fetchEmployees();
//   }
// }

import 'package:flutter/material.dart';
import '../models/employee.dart';
import '../services/api_service.dart';

class EmployeeController extends ChangeNotifier {
  List<Employee> _employees = [];
  bool _isLoading = false;

  List<Employee> get employees => _employees;
  bool get isLoading => _isLoading;

  EmployeeController() {
    fetchEmployees();
  }

  Future<void> fetchEmployees() async {
    _isLoading = true;
    notifyListeners();
    try {
      _employees = await ApiService().fetchEmployees();
    } catch (e) {
      print(e);
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> addEmployee(Employee employee) async {
    try {
      await ApiService().addEmployee(employee);
      _employees.add(employee);
      notifyListeners();
    } catch (e) {
      print(e);
    }
  }

  Future<void> deleteEmployee(String id) async {
    try {
      await ApiService().deleteEmployee(id);
      _employees.removeWhere((employee) => employee.empId == id);
      notifyListeners();
    } catch (e) {
      print(e);
    }
  }
}
