class Employee {
  final String empId;
  final String name;
  final String address;
  final List<ContactMethod> contactMethods;
  final String photoUrl;

  Employee({
    this.empId = '',
    required this.name,
    required this.address,
    required this.contactMethods,
    required this.photoUrl,
  });

  factory Employee.fromJson(Map<String, dynamic> json) {
    var list = json['contactMethods'] as List;
    List<ContactMethod> contactMethodsList =
        list.map((i) => ContactMethod.fromJson(i)).toList();

    return Employee(
      empId: json['empId'],
      name: json['name'],
      address: json['address'],
      contactMethods: contactMethodsList,
      photoUrl: json['photoUrl'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'address': address,
      'contactMethods': contactMethods.map((e) => e.toJson()).toList(),
      'photoUrl': photoUrl,
    };
  }
}

class ContactMethod {
  final String contactMethod;
  final String value;

  ContactMethod({
    required this.contactMethod,
    required this.value,
  });

  factory ContactMethod.fromJson(Map<String, dynamic> json) {
    return ContactMethod(
      contactMethod: json['contactMethod'],
      value: json['value'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'contactMethod': contactMethod,
      'value': value,
    };
  }
}
