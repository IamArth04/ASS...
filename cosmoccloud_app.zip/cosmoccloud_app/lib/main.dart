import 'package:flutter/material.dart';
import 'package:cosmoccloud_app/controllers/employee_controller.dart';
import 'package:cosmoccloud_app/views/employee_list_screen.dart';
import 'package:provider/provider.dart';

void main() {
  WidgetsFlutterBinding
      .ensureInitialized(); // Ensures the initialization is completed before runApp
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => EmployeeController(),
      child: MaterialApp(
        title: 'Employee Management',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: EmployeeListScreen(),
      ),
    );
  }
}
