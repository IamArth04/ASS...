import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/employee_controller.dart';
import 'package:cosmoccloud_app/views/employee_detail_screen.dart';
// import 'package:cosmoccloud_app/views/add_employee_screen.dart';
// import 'package:cosmoccloud_app/consts/colors.dart';

class EmployeeListScreen extends StatelessWidget {
  const EmployeeListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Employees'),
      ),
      body: Consumer<EmployeeController>(
        builder: (context, employeeController, child) {
          if (employeeController.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (employeeController.employees.isEmpty) {
            return const Center(child: Text('No Employees in the system'));
          }

          return ListView.builder(
            itemCount: employeeController.employees.length,
            itemBuilder: (context, index) {
              final employee = employeeController.employees[index];
              return ListTile(
                title: Text(employee.name),
                subtitle: Text('ID: ${employee.empId}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    employeeController.deleteEmployee(employee.empId);
                  },
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          EmployeeDetailScreen(employeeId: employee.empId),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
