import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/employee_controller.dart';
import '../models/employee.dart';
import '../consts/colors.dart';

class AddEmployeeScreen extends StatefulWidget {
  @override
  _AddEmployeeScreenState createState() => _AddEmployeeScreenState();
}

class _AddEmployeeScreenState extends State<AddEmployeeScreen> {
  final _formKey = GlobalKey<FormState>();
  String _name = '';
  String _address = '';
  List<ContactMethod> _contactMethods = [];
  String _photoUrl = '';

  final _contactMethodController = TextEditingController();
  final _valueController = TextEditingController();

  void _addContactMethod() {
    if (_contactMethodController.text.isNotEmpty &&
        _valueController.text.isNotEmpty) {
      setState(() {
        _contactMethods.add(ContactMethod(
          contactMethod: _contactMethodController.text,
          value: _valueController.text,
        ));
      });
      _contactMethodController.clear();
      _valueController.clear();
    }
  }

  @override
  void dispose() {
    _contactMethodController.dispose();
    _valueController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Employee')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (value) =>
                    value!.isEmpty ? 'Please enter a name' : null,
                onSaved: (value) => _name = value!,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Address'),
                validator: (value) =>
                    value!.isEmpty ? 'Please enter an address' : null,
                onSaved: (value) => _address = value!,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Photo URL'),
                validator: (value) =>
                    value!.isEmpty ? 'Please enter a photo URL' : null,
                onSaved: (value) => _photoUrl = value!,
              ),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _contactMethodController,
                      decoration:
                          const InputDecoration(labelText: 'Contact Method'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextFormField(
                      controller: _valueController,
                      decoration: const InputDecoration(labelText: 'Value'),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: _addContactMethod,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView.builder(
                  itemCount: _contactMethods.length,
                  itemBuilder: (context, index) {
                    final method = _contactMethods[index];
                    return ListTile(
                      title: Text('${method.contactMethod}: ${method.value}'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          setState(() {
                            _contactMethods.removeAt(index);
                          });
                        },
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(primaryColor)),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    final newEmployee = Employee(
                      name: _name,
                      address: _address,
                      contactMethods: _contactMethods,
                      photoUrl: _photoUrl,
                    );
                    Provider.of<EmployeeController>(context, listen: false)
                        .addEmployee(newEmployee);
                    Navigator.pop(context);
                  }
                },
                child: const Text('Add Employee'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
