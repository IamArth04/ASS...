import 'package:flutter/material.dart';
import 'package:cosmoccloud_app/controllers/employee_controller.dart';
import 'package:provider/provider.dart';
import 'package:cosmoccloud_app/views/main_screen.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => EmployeeController(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => EmployeeController(),
      child: MaterialApp(
        title: 'Employee Management',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: const MainScreen(),
      ),
    );
  }
}
