import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/employee_controller.dart';
import '../models/employee.dart';

class AddEmployeeScreen extends StatefulWidget {
  const AddEmployeeScreen({super.key});

  @override
  _AddEmployeeScreenState createState() => _AddEmployeeScreenState();
}

class _AddEmployeeScreenState extends State<AddEmployeeScreen> {
  final _formKey = GlobalKey<FormState>();
  String _name = '';
  String _address = '';
  String _photoUrl = '';
  final List<ContactMethod> _contactMethods = [
    ContactMethod(contactMethod: 'EMAIL', value: '')
  ];

  void _addContactMethod() {
    setState(() {
      _contactMethods.add(ContactMethod(contactMethod: 'EMAIL', value: ''));
    });
  }

  void _removeContactMethod(int index) {
    setState(() {
      _contactMethods.removeAt(index);
    });
  }

  void _saveForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final newEmployee = Employee(
        name: _name,
        address: _address,
        photoUrl: _photoUrl,
        contactMethods: _contactMethods,
      );
      Provider.of<EmployeeController>(context, listen: false)
          .addEmployee(newEmployee);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Add Employee',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter a name';
                  }
                  return null;
                },
                onSaved: (value) {
                  _name = value!;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Address'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter an address';
                  }
                  return null;
                },
                onSaved: (value) {
                  _address = value!;
                },
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Photo URL'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter a photo URL';
                  }
                  return null;
                },
                onSaved: (value) {
                  _photoUrl = value!;
                },
              ),
              const SizedBox(height: 16),
              const Text('Contact Methods', style: TextStyle(fontSize: 16)),
              ..._contactMethods.map((contactMethod) {
                int index = _contactMethods.indexOf(contactMethod);
                return Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField(
                        value: contactMethod.contactMethod,
                        items: ['EMAIL', 'PHONE'].map((method) {
                          return DropdownMenuItem(
                            value: method,
                            child: Text(method),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _contactMethods[index] = ContactMethod(
                                contactMethod: value as String,
                                value: contactMethod.value);
                          });
                        },
                      ),
                    ),
                    Expanded(
                      child: TextFormField(
                        decoration: const InputDecoration(labelText: 'Value'),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter a value';
                          }
                          return null;
                        },
                        onChanged: (value) {
                          _contactMethods[index] = ContactMethod(
                              contactMethod: contactMethod.contactMethod,
                              value: value);
                        },
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.remove_circle, color: Colors.red),
                      onPressed: () {
                        _removeContactMethod(index);
                      },
                    ),
                  ],
                );
              }),
              TextButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Add Contact Method'),
                onPressed: _addContactMethod,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _saveForm,
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
