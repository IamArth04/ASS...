import 'package:flutter/material.dart';
import 'package:cosmoccloud_app/services/api_service.dart';
import 'package:cosmoccloud_app/models/employee.dart';

class EmployeeDetailScreen extends StatelessWidget {
  final String employeeId;

  EmployeeDetailScreen({required this.employeeId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Employee Details')),
      body: FutureBuilder<Employee>(
        future: ApiService().fetchEmployeeById(employeeId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData) {
            return const Center(child: Text('Employee not found'));
          } else {
            final employee = snapshot.data!;
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.network(employee.photoUrl,
                      height: 200, width: double.infinity, fit: BoxFit.cover),
                  const SizedBox(height: 16),
                  Text('Name: ${employee.name}',
                      style: const TextStyle(fontSize: 18)),
                  Text('Address: ${employee.address}',
                      style: const TextStyle(fontSize: 18)),
                  const SizedBox(height: 16),
                  const Text('Contact Methods:',
                      style: TextStyle(fontSize: 18)),
                  ...employee.contactMethods.map((method) =>
                      Text('${method.contactMethod}: ${method.value}')),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
