import 'package:flutter/material.dart';

const primaryColor = Colors.blue;
