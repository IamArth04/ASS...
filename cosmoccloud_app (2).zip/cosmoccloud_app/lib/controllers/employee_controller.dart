import 'package:flutter/material.dart';
import '../models/employee.dart';
import '../services/api_service.dart';

class EmployeeController extends ChangeNotifier {
  List<Employee> _employees = [];
  bool _isLoading = false;

  List<Employee> get employees => _employees;
  bool get isLoading => _isLoading;

  EmployeeController() {
    fetchEmployees();
  }

  Future<void> fetchEmployees() async {
    _isLoading = true;
    notifyListeners();
    try {
      _employees = await ApiService().fetchEmployees();
    } catch (e) {
      print(e);
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> addEmployee(Employee employee) async {
    try {
      await ApiService().addEmployee(employee);
      _employees.add(employee);
      notifyListeners();
    } catch (e) {
      print(e);
    }
  }

  Future<void> deleteEmployee(String id) async {
    try {
      await ApiService().deleteEmployee(id);
      _employees.removeWhere((employee) => employee.empId == id);
      notifyListeners();
    } catch (e) {
      print(e);
    }
  }
}
