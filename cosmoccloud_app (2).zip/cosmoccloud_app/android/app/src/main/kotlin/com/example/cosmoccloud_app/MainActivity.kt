package com.example.cosmoccloud_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
